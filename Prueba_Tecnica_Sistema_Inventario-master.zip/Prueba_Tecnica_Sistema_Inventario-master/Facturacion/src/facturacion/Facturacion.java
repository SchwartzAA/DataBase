package facturacion;

public class Facturacion {

    public static void main(String[] args) {
       new Interfaz_principal().setVisible(true);
    }

   
}
