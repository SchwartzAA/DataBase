# Proyecto Sistema de inventario. 

Para iniciar el proyecto primero debe:

1. Crear una base de datos en MySQL y correr el script .sql que esta en la carpeta bases de datos 

2. Debe modificar la conexión a la base de datos en el archivo conexion.java con la url, usuario y contraseña de nuestro servidor de base de datos, en caso que tengas una base de datos local, entonces deja el url por defecto y modifica el usuario y contraseña.

3. Debe añadir las librerias que se encuentran en la carpeta componentes para poder correr el programa sin ningún problema.

